// Get the button element
var btn = document.querySelector('.btn');

// Add a click event listener to the button
btn.addEventListener('click', function() {
	alert('You clicked the button!');
});
